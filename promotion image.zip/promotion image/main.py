from flask import Flask

app = Flask(__name__)


@app.route('/')
@app.route('/home')
def home():
    return """<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Миссия Колонизация Марса</title>
                  </head>
                  <body>
                    <h1>Миссия Колонизация Марса</h1>
                  </body>
                </html>"""


@app.route('/index')
def index():
    return """<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Миссия Колонизация Марса</title>
                  </head>
                  <body>
                    <h1>И на Марсе будут яблони цвести!</h1>
                  </body>
                </html>"""


@app.route("/promotion")
def promotion():
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous">
                    <title>Миссия Колонизация Марса</title>
                  </head>
                  <body>
                    <h1>И на Марсе будут яблони цвести!</h1>
                    <div class="alert alert-primary" role="alert">
                      Человечество вырастает из детства.<br>
                      Человечеству мала одна планета.<br>
                      Мы сделаем обитаемыми безжизненные пока планеты.<br>
                      И начнем с Марса!<br>
                      Присоединяйся!
                    </div>
                  </body>
                </html>'''


@app.route('/image_mars')
def image_mars():
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Привет, Марс!</title>
                  </head>
                  <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="https://cs6.pikabu.ru/avatars/1126/v1126093-1625455561.jpg" 
                    alt="здесь должна была быть картинка, но не нашлась">
                    <h4>Так вот она какая, красная планета!<h4>
                    <div class="alert alert-primary" role="alert">
                    </div>
                  </body>
                </html>'''


@app.route('/promotion_image')
def promotion_image():
    return '''<!doctype html>
              <html lang="en">
                <head>
                  <meta charset="UTF-8">
                  <title>promotion_image</title>
                  <link rel="stylesheet" href="static/css/style.css">
                </head>
                  <body>
                    <h1 style="color: #FF0000">Жди нас, Марс</h1>
                    <img src="static/img/mars-img.png" width="500px" height="300px">
                    <div class="dark-grey">Человечество вырастает из детства.<br></div>
                    <div class="green">Человечеству мала одна планета.<br></div>
                    <div class="grey">Мы сделаем обитаемыми безжизненные пока планеты.<br></div>
                    <div class="yellow">И начнем с Марса!<br></div>
                    <div class="red">Присоединяйся!</div>
                  </body>
              </html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')